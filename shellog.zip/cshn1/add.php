<?php

include 'db.php';

    $ip = $_SERVER['REMOTE_ADDR'];
    $log = "http://".$_SERVER['HTTP_HOST']."".$_SERVER['REQUEST_URI']."";


    $ekle=$db->prepare("insert into links set ip=?,log=?");
    $ekle ->execute(array($ip,$log));
    




?>

