<?php
session_start();
include 'db.php';
$query = $db->prepare('SELECT * FROM users WHERE user_name = ? && user_password = ?');

if ($_POST) {
    $username = $_POST[@'username'];
    $password = $_POST[@'password'];
    $password = md5($password);


    $query->execute([
        $username, $password
    ]);
    $row = $query->fetch(PDO::FETCH_ASSOC);


    if ($query->rowCount() > 0) {
        $_SESSION['user'] = $row['user_name'];
        header('Location:/');
    }


}
?>
<html>
<head>
  <link rel="shortcut icon" type="image/png" href="cshn1/favicon.ico"/>
<title>>_</title>
    <style type="text/css">
<!--
.style7 {font-family: "Courier New", Courier, monospace; font-size: 12px;}
.style8 {color: #FFFFFF}
.tb2 {
    background-color : #363636;
    border: 1px dotted #008000;
    width: 230px;
}
.tb3 {
    background-color : #000;
    border: 1px dotted #008000;
    width: 90px;
    color: #bf0000;
}
-->
    </style>
</head>
<body bgcolor="#000000">
<div align="center">
<br/>
<br/>
<br/>
<br/>
<form action="" method="POST">
  <table width="500" border="0">
    <tr>
      <td colspan="3"><div align="center"><img src="x.gif"></div><br/></td>
    </tr>
    <tr>
      <td><div align="center" style="color:#ff0000;">Kullanici Adi </div></td>
      <td><div align="center" style="color:#ff0000;">:</div></td>
      <td><input class="tb2" type="text" name="username" style="color:#ff0000;"></td>
    </tr>
    <tr>
      <td><div align="center" style="color:#ff0000;">Sifre</div></td>
      <td><div align="center" style="color:#ff0000;">:</div></td>
      <td><input class="tb2" type="password" name="password" style="color:#ff0000;"></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td><button class="tb3" type="submit">Log In</button></td>
    </tr>
  </table>
  <br/> <br/> <br/> <br/>
  <center><span style="color:#1c1c1c; font-family: Courier New, Courier, monospace; font-size: 12px;">--=== Güvenlik nedeniyle ip'niz alındı. ===--</span></center>
    <center><span style="color:#1c1c1c; font-family: Courier New, Courier, monospace; font-size: 12px;">[ <?php
    $IPaddress=$_SERVER['REMOTE_ADDR']; 
   echo "ip adresiniz: $IPaddress ";
?> ]</span></center>
  </form>

</div>
</body>
</html>